<?php
include('sessao.php');
include('conexao.php');

// Obter a lista de ocorrências para exibir na tabela
$stmt = $pdo->query('SELECT id, descricao, tipo FROM ocorrencias');
$ocorrencias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Ocorrências</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Alterar Ocorrências</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ocorrência</th>
                    <th>Tipo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ocorrencias as $ocorrencia): ?>
                    <tr>
                        <td><?php echo $ocorrencia['id']; ?></td>
                        <td><?php echo $ocorrencia['descricao']; ?></td>
                        <td><?php echo $ocorrencia['tipo']; ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#modalEditar<?php echo $ocorrencia['id']; ?>">Editar</button>
                            <a href="apagar_ocorrencia.php?id=<?php echo $ocorrencia['id']; ?>" class="btn btn-danger btn-sm">Apagar</a>
                        </td>
                    </tr>
                    <!-- Modal para editar ocorrência -->
                    <div class="modal fade" id="modalEditar<?php echo $ocorrencia['id']; ?>" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEditarLabel">Editar Ocorrência</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form method="post" action="editar_ocorrencia.php">
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?php echo $ocorrencia['id']; ?>">
                                        <div class="form-group">
                                            <label for="descricao">Descrição:</label>
                                            <input type="text" class="form-control" id="descricao" name="descricao" value="<?php echo $ocorrencia['descricao']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="tipo">Tipo:</label>
                                            <select class="form-control" id="tipo" name="tipo" required>
                                                <option value="PLANEJADA" <?php echo ($ocorrencia['tipo'] == 'PLANEJADA') ? 'selected' : ''; ?>>PLANEJADA</option>
                                                <option value="NAO_PLANEJADA" <?php echo ($ocorrencia['tipo'] == 'NAO_PLANEJADA') ? 'selected' : ''; ?>>NÃO PLANEJADA</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                        <button type="submit" class="btn btn-primary">Salvar alterações</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
include('sessao.php');
include('conexao.php');

$data_inicial = isset($_GET['data_inicial']) ? $_GET['data_inicial'] : '';
$data_final = isset($_GET['data_final']) ? $_GET['data_final'] : '';
$numero_serie = isset($_GET['numero_serie']) ? $_GET['numero_serie'] : '';

// Consulta para obter os relatórios filtrados
$query = 'SELECT cp.id, m.numero_serie, cp.capacidade_instalada, cp.capacidade_disponivel, cp.capacidade_efetiva, cp.capacidade_realizada, cp.g_disponibilidade, cp.g_utilizacao, cp.i_eficiencia, cp.data_calculo FROM capacidade_produtiva cp JOIN maquinas m ON cp.maquina_id = m.id WHERE 1=1';
$params = [];

if ($data_inicial && $data_final) {
    $query .= ' AND cp.data_calculo BETWEEN ? AND ?';
    $params[] = $data_inicial;
    $params[] = $data_final;
} elseif ($data_inicial) {
    $query .= ' AND cp.data_calculo >= ?';
    $params[] = $data_inicial;
} elseif ($data_final) {
    $query .= ' AND cp.data_calculo <= ?';
    $params[] = $data_final;
}

if ($numero_serie) {
    $query .= ' AND m.numero_serie = ?';
    $params[] = $numero_serie;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios por Máquina</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    <script>
        window.jsPDF = window.jspdf.jsPDF;

        function exportarPDF() {
            const doc = new jsPDF();
            doc.text("Relatórios por Máquina", 10, 10);

            const head = [['ID', 'N. Série', 'C. Inst', 'C. Disp', 'C. Ef', 'C. Real', 'Grau de Disponibilidade', 'Grau de Utilização', 'Índice de Eficiência', 'Data Cálculo']];
            const body = [];

            const rows = document.querySelectorAll("table tbody tr");
            rows.forEach((row, index) => {
                const cells = row.querySelectorAll("td");
                const rowData = [];
                cells.forEach(cell => {
                    rowData.push(cell.innerText);
                });
                body.push(rowData);
            });

            doc.autoTable({
                head: head,
                body: body,
                startY: 20,
                styles: { fillColor: [255, 255, 255], textColor: [0, 0, 0] },
                alternateRowStyles: { fillColor: [240, 240, 240] },
                headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255] },
                theme: 'grid',
                margin: { top: 20 },
            });

            doc.save("relatorios_maquinas.pdf");
        }
    </script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Relatórios por Máquina</h2>
        <form method="get" action="relatorios_maquinas.php" class="mb-3">
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="data_inicial">Data Inicial:</label>
                    <input type="date" class="form-control" id="data_inicial" name="data_inicial" value="<?php echo $data_inicial; ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="data_final">Data Final:</label>
                    <input type="date" class="form-control" id="data_final" name="data_final" value="<?php echo $data_final; ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="numero_serie">N. Série:</label>
                    <input type="text" class="form-control" id="numero_serie" name="numero_serie" value="<?php echo $numero_serie; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </form>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>N. Série</th>
                    <th>C. Inst</th>
                    <th>C. Disp</th>
                    <th>C. Ef</th>
                    <th>C. Real</th>
                    <th>Grau de Disponibilidade</th>
                    <th>Grau de Utilização</th>
                    <th>Índice de Eficiência</th>
                    <th>Data Cálculo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($relatorios as $relatorio): ?>
                    <tr>
                        <td><?php echo $relatorio['id']; ?></td>
                        <td><?php echo $relatorio['numero_serie']; ?></td>
                        <td><?php echo $relatorio['capacidade_instalada']; ?></td>
                        <td><?php echo $relatorio['capacidade_disponivel']; ?></td>
                        <td><?php echo $relatorio['capacidade_efetiva']; ?></td>
                        <td><?php echo $relatorio['capacidade_realizada']; ?></td>
                        <td><?php echo $relatorio['g_disponibilidade']; ?></td>
                        <td><?php echo $relatorio['g_utilizacao']; ?></td>
                        <td><?php echo $relatorio['i_eficiencia']; ?></td>
                        <td><?php echo $relatorio['data_calculo']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="exportar_csv.php?data_inicial=<?php echo $data_inicial; ?>&data_final=<?php echo $data_final; ?>&numero_serie=<?php echo $numero_serie; ?>" class="btn btn-secondary">Exportar CSV</a>
        <button onclick="exportarPDF()" class="btn btn-secondary">Exportar PDF</button>
    </div>
</body>
</html>

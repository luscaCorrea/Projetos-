<?php
include('sessao.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Menu Principal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Menu Principal</h2>
        <div class="row">
            <div class="col-md-4">
                <a href="cadastrar_usuario.php" class="btn btn-dark btn-block">Cadastrar Usuários</a>
            </div>
            <div class="col-md-4">
                <a href="alterar_usuario.php" class="btn btn-dark btn-block">Alterar Usuários</a>
            </div>
            <div class="col-md-4">
                <a href="cadastrar_setor.php" class="btn btn-dark btn-block">Cadastrar Setores</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="alterar_setor.php" class="btn btn-dark btn-block">Alterar Setores</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="cadastrar_maquina.php" class="btn btn-dark btn-block">Cadastrar Máquinas</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="alterar_maquinas.php" class="btn btn-dark btn-block">Alterar Máquinas</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="cadastrar_ocorrencia.php" class="btn btn-dark btn-block">Cadastrar Ocorrências</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="alterar_ocorrencias.php" class="btn btn-dark btn-block">Alterar Ocorrências</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="calcular_capacidade.php" class="btn btn-dark btn-block">Calcular Cap. Produtiva</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="relatorios_maquinas.php" class="btn btn-dark btn-block">Relatórios MAQ</a>
            </div>
            <div class="col-md-4 mt-2">
                <a href="logout.php" class="btn btn-secondary btn-block">Logoff</a>
            </div>
        </div>
    </div>
</body>
</html>

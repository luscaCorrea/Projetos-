<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $descricao = $_POST['descricao'];
    $tipo = $_POST['tipo'];

    $stmt = $pdo->prepare('INSERT INTO ocorrencias (descricao, tipo) VALUES (?, ?)');
    $stmt->execute([$descricao, $tipo]);

    header('Location: menu.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Ocorrência</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Cadastro de Ocorrências</h2>
        <form method="post" action="cadastrar_ocorrencia.php">
            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <input type="text" class="form-control" id="descricao" name="descricao" required>
            </div>
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select class="form-control" id="tipo" name="tipo" required>
                    <option value="PLANEJADA">PLANEJADA</option>
                    <option value="NAO_PLANEJADA">NÃO PLANEJADA</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
            <a href="menu.php" class="btn btn-secondary">Voltar</a>
        </form>
    </div>
</body>
</html>

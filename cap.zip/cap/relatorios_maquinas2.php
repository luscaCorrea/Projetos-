<?php
include('sessao.php');
include('conexao.php');

$data = isset($_GET['data']) ? $_GET['data'] : '';
$numero_serie = isset($_GET['numero_serie']) ? $_GET['numero_serie'] : '';

// Consulta para obter os relatórios filtrados
$query = 'SELECT cp.id, m.numero_serie, cp.capacidade_instalada, cp.capacidade_disponivel, cp.capacidade_efetiva, cp.capacidade_realizada, cp.data_calculo FROM capacidade_produtiva cp JOIN maquinas m ON cp.maquina_id = m.id WHERE 1=1';
$params = [];

if ($data) {
    $query .= ' AND cp.data_calculo = ?';
    $params[] = $data;
}

if ($numero_serie) {
    $query .= ' AND m.numero_serie = ?';
    $params[] = $numero_serie;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios por Máquina</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.amazonaws.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Relatórios por Máquina</h2>
        <form method="get" action="relatorios_maquinas.php" class="mb-3">
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="data">Data:</label>
                    <input type="date" class="form-control" id="data" name="data" value="<?php echo $data; ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="numero_serie">N. Série:</label>
                    <input type="text" class="form-control" id="numero_serie" name="numero_serie" value="<?php echo $numero_serie; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </form>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>N. Série</th>
                    <th>C. Inst</th>
                    <th>C. Disp</th>
                    <th>C. Ef</th>
                    <th>C. Real</th>
                    <th>Data Cálculo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($relatorios as $relatorio): ?>
                    <tr>
                        <td><?php echo $relatorio['id']; ?></td>
                        <td><?php echo $relatorio['numero_serie']; ?></td>
                        <td><?php echo $relatorio['capacidade_instalada']; ?></td>
                        <td><?php echo $relatorio['capacidade_disponivel']; ?></td>
                        <td><?php echo $relatorio['capacidade_efetiva']; ?></td>
                        <td><?php echo $relatorio['capacidade_realizada']; ?></td>
                        <td><?php echo $relatorio['data_calculo']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="exportar_csv.php?data=<?php echo $data; ?>&numero_serie=<?php echo $numero_serie; ?>" class="btn btn-secondary">Exportar CSV</a>
        <a href="exportar_pdf.php?data=<?php echo $data; ?>&numero_serie=<?php echo $numero_serie; ?>" class="btn btn-secondary">Exportar PDF</a>
    </div>
</body>
</html>

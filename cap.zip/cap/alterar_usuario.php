<?php
include('sessao.php');
include('conexao.php');

// Obter a lista de usuários
$stmt = $pdo->query('SELECT id, nome, email, tipo, status FROM usuarios');
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['editar'])) {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $tipo = $_POST['tipo'];
        $status = $_POST['status'];

        $stmt = $pdo->prepare('UPDATE usuarios SET nome = ?, email = ?, tipo = ?, status = ? WHERE id = ?');
        $stmt->execute([$nome, $email, $tipo, $status, $id]);

        header('Location: alterar_usuario.php');
        exit;
    } elseif (isset($_POST['apagar'])) {
        $id = $_POST['id'];

        $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id = ?');
        $stmt->execute([$id]);

        header('Location: alterar_usuario.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Usuários</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.editarUsuario').click(function(){
                var id = $(this).data('id');
                var nome = $(this).data('nome');
                var email = $(this).data('email');
                var tipo = $(this).data('tipo');
                var status = $(this).data('status');

                $('#usuarioId').val(id);
                $('#nome').val(nome);
                $('#email').val(email);
                $('#tipo').val(tipo);
                $('#status').val(status);

                $('#modalEditarUsuario').modal('show');
            });

            $('.apagarUsuario').click(function(){
                var id = $(this).data('id');

                $('#usuarioIdApagar').val(id);

                $('#modalApagarUsuario').modal('show');
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Alterar Usuários</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?php echo $usuario['id']; ?></td>
                        <td><?php echo $usuario['nome']; ?></td>
                        <td><?php echo $usuario['email']; ?></td>
                        <td><?php echo $usuario['tipo']; ?></td>
                        <td><?php echo $usuario['status']; ?></td>
                        <td>
                            <button class="btn btn-primary editarUsuario" data-id="<?php echo $usuario['id']; ?>" data-nome="<?php echo $usuario['nome']; ?>" data-email="<?php echo $usuario['email']; ?>" data-tipo="<?php echo $usuario['tipo']; ?>" data-status="<?php echo $usuario['status']; ?>">Editar</button>
                            <button class="btn btn-danger apagarUsuario" data-id="<?php echo $usuario['id']; ?>">Apagar</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="menu.php" class="btn btn-secondary">Voltar</a>
    </div>

    <!-- Modal para editar usuário -->
    <div class="modal fade" id="modalEditarUsuario" tabindex="-1" aria-labelledby="modalEditarUsuarioLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditarUsuarioLabel">Editar Usuário</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="alterar_usuario.php">
                        <input type="hidden" name="id" id="usuarioId">
                        <div class="form-group">
                            <label for="nome">Nome:</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="tipo">Tipo:</label>
                            <select class="form-control" id="tipo" name="tipo" required>
                                <option value="ADMIN">ADMIN</option>
                                <option value="USER">USER</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select class="form-control" id="status" name="status" required>
                                <option value="ATIVO">ATIVO</option>
                                <option value="INATIVO">INATIVO</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="editar">Salvar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para apagar usuário -->
    <div class="modal fade" id="modalApagarUsuario" tabindex="-1" aria-labelledby="modalApagarUsuarioLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalApagarUsuarioLabel">Apagar Usuário</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza que deseja apagar este usuário?</p>
                    <form method="post" action="alterar_usuario.php">
                        <input type="hidden" name="id" id="usuarioIdApagar">
                        <button type="submit" class="btn btn-danger" name="apagar">Apagar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['editar'])) {
        $id = $_POST['id'];
        $descricao = $_POST['descricao'];
        $setor_id = $_POST['setor_id'];
        $numero_serie = $_POST['numero_serie'];
        $capacidade_nominal = $_POST['capacidade_nominal'];
        $observacoes = $_POST['observacoes'];

        $stmt = $pdo->prepare('UPDATE maquinas SET nome = ?, setor_id = ?, numero_serie = ?, capacidade_nominal = ?, observacoes = ? WHERE id = ?');
        $stmt->execute([$descricao, $setor_id, $numero_serie, $capacidade_nominal, $observacoes, $id]);

        header('Location: alterar_maquinas.php');
        exit;
    } elseif (isset($_POST['apagar'])) {
        $id = $_POST['id'];

        $stmt = $pdo->prepare('DELETE FROM maquinas WHERE id = ?');
        $stmt->execute([$id]);

        header('Location: alterar_maquinas.php');
        exit;
    }
}

// Obter a lista de setores para o dropdown
$stmt = $pdo->query('SELECT id, nome FROM setores');
$setores = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter a lista de máquinas
$stmt = $pdo->query('SELECT m.id, m.nome, m.numero_serie, m.capacidade_nominal, m.observacoes, s.id AS setor_id, s.nome AS setor_nome FROM maquinas m JOIN setores s ON m.setor_id = s.id');
$maquinas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Máquinas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.editarMaquina').click(function(){
                var id = $(this).data('id');
                var descricao = $(this).data('descricao');
                var setor_id = $(this).data('setor_id');
                var numero_serie = $(this).data('numero_serie');
                var capacidade_nominal = $(this).data('capacidade_nominal');
                var observacoes = $(this).data('observacoes');

                $('#maquinaId').val(id);
                $('#descricao').val(descricao);
                $('#setor_id').val(setor_id);
                $('#numero_serie').val(numero_serie);
                $('#capacidade_nominal').val(capacidade_nominal);
                $('#observacoes').val(observacoes);

                $('#modalEditarMaquina').modal('show');
            });

            $('.apagarMaquina').click(function(){
                var id = $(this).data('id');

                $('#maquinaIdApagar').val(id);

                $('#modalApagarMaquina').modal('show');
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Alterar Máquinas</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Descrição</th>
                    <th>Setor</th>
                    <th>N. Série</th>
                    <th>V. Nominal (peças/horas)</th>
                    <th>Observações</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($maquinas as $maquina): ?>
                    <tr>
                        <td><?php echo $maquina['id']; ?></td>
                        <td><?php echo $maquina['nome']; ?></td>
                        <td><?php echo $maquina['setor_nome']; ?></td>
                        <td><?php echo $maquina['numero_serie']; ?></td>
                        <td><?php echo $maquina['capacidade_nominal']; ?></td>
                        <td><?php echo $maquina['observacoes']; ?></td>
                        <td>
                            <button class="btn btn-primary editarMaquina" 
                                    data-id="<?php echo $maquina['id']; ?>" 
                                    data-descricao="<?php echo $maquina['nome']; ?>" 
                                    data-setor_id="<?php echo $maquina['setor_id']; ?>" 
                                    data-numero_serie="<?php echo $maquina['numero_serie']; ?>" 
                                    data-capacidade_nominal="<?php echo $maquina['capacidade_nominal']; ?>" 
                                    data-observacoes="<?php echo $maquina['observacoes']; ?>">
                                Editar
                            </button>
                            <button class="btn btn-danger apagarMaquina" data-id="<?php echo $maquina['id']; ?>">Apagar</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="menu.php" class="btn btn-secondary">Voltar</a>
    </div>

    <!-- Modal para editar máquina -->
    <div class="modal fade" id="modalEditarMaquina" tabindex="-1" aria-labelledby="modalEditarMaquinaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditarMaquinaLabel">Editar Máquina</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="alterar_maquinas.php">
                        <input type="hidden" name="id" id="maquinaId">
                        <div class="form-group">
                            <label for="descricao">Descrição:</label>
                            <input type="text" class="form-control" id="descricao" name="descricao" required>
                        </div>
                        <div class="form-group">
                            <label for="setor_id">Setor:</label>
                            <select class="form-control" id="setor_id" name="setor_id" required>
                                <?php foreach ($setores as $setor): ?>
                                    <option value="<?php echo $setor['id']; ?>"><?php echo $setor['nome']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="numero_serie">N. Série:</label>
                            <input type="text" class="form-control" id="numero_serie" name="numero_serie" required>
                        </div>
                        <div class="form-group">
                            <label for="capacidade_nominal">V. Nominal (peças/horas):</label>
                            <input type="number" class="form-control" id="capacidade_nominal" name="capacidade_nominal" required>
                        </div>
                        <div class="form-group">
                            <label for="observacoes">Observações:</label>
                            <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" name="editar">Salvar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para apagar máquina -->
    <div class="modal fade" id="modalApagarMaquina" tabindex="-1" aria-labelledby="modalApagarMaquinaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalApagarMaquinaLabel">Apagar Máquina</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza que deseja apagar esta máquina?</p>
                    <form method="post" action="alterar_maquinas.php">
                        <input type="hidden" name="id" id="maquinaIdApagar">
                        <button type="submit" class="btn btn-danger" name="apagar">Apagar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

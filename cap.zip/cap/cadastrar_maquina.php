<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $descricao = $_POST['descricao'];
    $setor_id = $_POST['setor_id'];
    $numero_serie = $_POST['numero_serie'];
    $capacidade_nominal = $_POST['capacidade_nominal'];
    $observacoes = $_POST['observacoes'];

    $stmt = $pdo->prepare('INSERT INTO maquinas (nome, setor_id, numero_serie, capacidade_nominal, observacoes) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$descricao, $setor_id, $numero_serie, $capacidade_nominal, $observacoes]);

    header('Location: menu.php');
    exit;
}

// Obter a lista de setores para o dropdown
$stmt = $pdo->query('SELECT id, nome FROM setores');
$setores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Máquina</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Cadastro de Máquinas</h2>
        <form method="post" action="cadastrar_maquina.php">
            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <input type="text" class="form-control" id="descricao" name="descricao" required>
            </div>
            <div class="form-group">
                <label for="setor_id">Setor:</label>
                <select class="form-control" id="setor_id" name="setor_id" required>
                    <?php foreach ($setores as $setor): ?>
                        <option value="<?php echo $setor['id']; ?>"><?php echo $setor['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="numero_serie">N. Série:</label>
                <input type="text" class="form-control" id="numero_serie" name="numero_serie" required>
            </div>
            <div class="form-group">
                <label for="capacidade_nominal">V. Nominal (peças/horas):</label>
                <input type="number" class="form-control" id="capacidade_nominal" name="capacidade_nominal" required>
            </div>
            <div class="form-group">
                <label for="observacoes">Observações:</label>
                <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
            <a href="menu.php" class="btn btn-secondary">Voltar</a>
        </form>
    </div>
</body>
</html>

<?php
include('sessao.php');
include('conexao.php');

$data_inicial = isset($_GET['data_inicial']) ? $_GET['data_inicial'] : '';
$data_final = isset($_GET['data_final']) ? $_GET['data_final'] : '';
$numero_serie = isset($_GET['numero_serie']) ? $_GET['numero_serie'] : '';

// Consulta para obter os relatórios filtrados
$query = 'SELECT cp.id, m.numero_serie, cp.capacidade_instalada, cp.capacidade_disponivel, cp.capacidade_efetiva, cp.capacidade_realizada, cp.g_disponibilidade, cp.g_utilizacao, cp.i_eficiencia, cp.data_calculo FROM capacidade_produtiva cp JOIN maquinas m ON cp.maquina_id = m.id WHERE 1=1';
$params = [];

if ($data_inicial && $data_final) {
    $query .= ' AND cp.data_calculo BETWEEN ? AND ?';
    $params[] = $data_inicial;
    $params[] = $data_final;
} elseif ($data_inicial) {
    $query .= ' AND cp.data_calculo >= ?';
    $params[] = $data_inicial;
} elseif ($data_final) {
    $query .= ' AND cp.data_calculo <= ?';
    $params[] = $data_final;
}

if ($numero_serie) {
    $query .= ' AND m.numero_serie = ?';
    $params[] = $numero_serie;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios por Máquina - Gráficos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Relatórios por Máquina - Gráficos</h2>
        <form method="get" action="relatorios_graficos2.php" class="mb-3">
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="data_inicial">Data Inicial:</label>
                    <input type="date" class="form-control" id="data_inicial" name="data_inicial" value="<?php echo $data_inicial; ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="data_final">Data Final:</label>
                    <input type="date" class="form-control" id="data_final" name="data_final" value="<?php echo $data_final; ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="numero_serie">N. Série:</label>
                    <input type="text" class="form-control" id="numero_serie" name="numero_serie" value="<?php echo $numero_serie; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </form>

        <div class="row">
            <div class="col-md-4 mb-3">
                <canvas id="grauDisponibilidadeChart"></canvas>
            </div>
            <div class="col-md-4 mb-3">
                <canvas id="grauUtilizacaoChart"></canvas>
            </div>
            <div class="col-md-4 mb-3">
                <canvas id="indiceEficienciaChart"></canvas>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const relatorios = <?php echo json_encode($relatorios); ?>;

                const labels = relatorios.map(relatorio => relatorio.data_calculo);
                const grauDisponibilidadeData = relatorios.map(relatorio => relatorio.g_disponibilidade);
                const grauUtilizacaoData = relatorios.map(relatorio => relatorio.g_utilizacao);
                const indiceEficienciaData = relatorios.map(relatorio => relatorio.i_eficiencia);

                const ctx1 = document.getElementById('grauDisponibilidadeChart').getContext('2d');
                new Chart(ctx1, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Grau de Disponibilidade (%)',
                            data: grauDisponibilidadeData,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });

                const ctx2 = document.getElementById('grauUtilizacaoChart').getContext('2d');
                new Chart(ctx2, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Grau de Utilização (%)',
                            data: grauUtilizacaoData,
                            backgroundColor: 'rgba(153, 102, 255, 0.2)',
                            borderColor: 'rgba(153, 102, 255, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });

                const ctx3 = document.getElementById('indiceEficienciaChart').getContext('2d');
                new Chart(ctx3, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Índice de Eficiência (%)',
                            data: indiceEficienciaData,
                            backgroundColor: 'rgba(255, 159, 64, 0.2)',
                            borderColor: 'rgba(255, 159, 64, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</body>
</html>

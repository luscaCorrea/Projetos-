<?php
include('sessao.php');
include('conexao.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare('DELETE FROM ocorrencias WHERE id = ?');
    $stmt->execute([$id]);

    header('Location: alterar_ocorrencias.php');
    exit;
}
?>

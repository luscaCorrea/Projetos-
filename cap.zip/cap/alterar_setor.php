<?php
include('sessao.php');
include('conexao.php');

// Obter a lista de setores
$stmt = $pdo->query('SELECT id, nome, observacoes FROM setores');
$setores = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['editar'])) {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $observacoes = $_POST['observacoes'];

        $stmt = $pdo->prepare('UPDATE setores SET nome = ?, observacoes = ? WHERE id = ?');
        $stmt->execute([$nome, $observacoes, $id]);

        header('Location: alterar_setor.php');
        exit;
    } elseif (isset($_POST['apagar'])) {
        $id = $_POST['id'];

        $stmt = $pdo->prepare('DELETE FROM setores WHERE id = ?');
        $stmt->execute([$id]);

        header('Location: alterar_setor.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Setores</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Alterar Setores</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Observações</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($setores as $setor): ?>
                    <tr>
                        <td><?php echo $setor['id']; ?></td>
                        <td><?php echo $setor['nome']; ?></td>
                        <td><?php echo $setor['observacoes']; ?></td>
                        <td>
                            <button class="btn btn-primary editarSetor" data-id="<?php echo $setor['id']; ?>" data-nome="<?php echo $setor['nome']; ?>" data-observacoes="<?php echo $setor['observacoes']; ?>">Editar</button>
                            <button class="btn btn-danger apagarSetor" data-id="<?php echo $setor['id']; ?>">Apagar</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="menu.php" class="btn btn-secondary">Voltar</a>
    </div>

    <!-- Modal para editar setor -->
    <div class="modal fade" id="modalEditarSetor" tabindex="-1" aria-labelledby="modalEditarSetorLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditarSetorLabel">Editar Setor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="alterar_setor.php">
                        <input type="hidden" name="id" id="setorId">
                        <div class="form-group">
                            <label for="nome">Nome:</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>
                        <div class="form-group">
                            <label for="observacoes">Observações:</label>
                            <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" name="editar">Salvar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para apagar setor -->
    <div class="modal fade" id="modalApagarSetor" tabindex="-1" aria-labelledby="modalApagarSetorLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalApagarSetorLabel">Apagar Setor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza que deseja apagar este setor?</p>
                    <form method="post" action="alterar_setor.php">
                        <input type="hidden" name="id" id="setorIdApagar">
                        <button type="submit" class="btn btn-danger" name="apagar">Apagar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $('.editarSetor').click(function(){
                var id = $(this).data('id');
                var nome = $(this).data('nome');
                var observacoes = $(this).data('observacoes');

                $('#setorId').val(id);
                $('#nome').val(nome);
                $('#observacoes').val(observacoes);

                $('#modalEditarSetor').modal('show');
            });

            $('.apagarSetor').click(function(){
                var id = $(this).data('id');

                $('#setorIdApagar').val(id);

                $('#modalApagarSetor').modal('show');
            });
        });
    </script>
</body>
</html>

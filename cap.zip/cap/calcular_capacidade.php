<?php
include('sessao.php');
include('conexao.php');

// Obter a lista de máquinas para o modal
$stmt = $pdo->query('SELECT id, numero_serie, nome, capacidade_nominal FROM maquinas');
$maquinas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter a lista de ocorrências para o modal
$stmt = $pdo->query('SELECT id, descricao, tipo FROM ocorrencias');
$ocorrencias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Calcular Capacidade Produtiva</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            var maquinas = <?php echo json_encode($maquinas); ?>;
            var ocorrencias = <?php echo json_encode($ocorrencias); ?>;

            $('#buscarMaquina').click(function(){
                $('#modalMaquina').modal('show');
            });

            $('#buscarOcorrencia').click(function(){
                $('#modalOcorrencia').modal('show');
            });

            $('#filtrarOcorrencias').click(function(){
                var tipo = $('#tipoOcorrencia').val();
                $('.ocorrencia').each(function(){
                    if ($(this).data('tipo') == tipo || tipo == '') {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });

            var contadorLinhas = 0;

            $('#adicionarOcorrencia').click(function(){
                contadorLinhas++;
                $('#modalOcorrencia').modal('show');
            });

            $(document).on('click', '.removerLinha', function(){
                $(this).closest('tr').remove();
            });

            $(document).on('click', '.editarHoras', function(){
                $(this).closest('tr').find('.horasInput').prop('disabled', false);
            });

            $(document).on('click', '.selecionarOcorrencia', function(){
                var id = $(this).data('id');
                var descricao = $(this).data('descricao');
                $('#tabelaOcorrencias tbody').append(`
                    <tr id="linha${contadorLinhas}">
                        <td><input type="hidden" name="ocorrencia_id[]" value="${id}">${id}</td>
                        <td>${descricao}</td>
                        <td><input type="number" class="form-control horasInput" name="horas[]" required></td>
                        <td>
                            <button type="button" class="btn btn-danger removerLinha">-</button>
                            <button type="button" class="btn btn-warning editarHoras">*</button>
                        </td>
                    </tr>
                `);
                $('#modalOcorrencia').modal('hide');
            });

            // Filtro de máquinas no modal
            $('#buscarMaquinaBtn').click(function() {
                var input = $('#buscarMaquinaInput').val().toLowerCase();
                $('.maquina').each(function() {
                    var serie = $(this).data('numero_serie').toLowerCase();
                    if (serie.includes(input)) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });

            // Seleção de máquina e preenchimento do campo "N. Série"
            $(document).on('click', '.selecionarMaquina', function(){
                var id = $(this).data('id');
                var numeroSerie = $(this).data('numero_serie');
                var capacidadeNominal = $(this).data('capacidade_nominal');
                $('#numeroSerie').val(numeroSerie);
                $('#maquina_id').val(id);
                $('#capacidade_nominal').val(capacidadeNominal);
                $('#modalMaquina').modal('hide');
            });

            // Mensagem "Máquina não encontrada"
            $('#modalMaquina').on('hidden.bs.modal', function() {
                if ($('#numeroSerie').val() === '') {
                    alert('Máquina não encontrada');
                }
            });

            $('#calcularBtn').click(function() {
                calcularCapacidade();
            });

            function calcularCapacidade() {
                var capacidadeNominal = parseInt($('#capacidade_nominal').val());
                var horasPorSemana = parseInt($('#horasPorSemana').val());
                var diasPorSemana = parseInt($('#diasPorSemana').val());

                if (isNaN(capacidadeNominal) || isNaN(horasPorSemana) || isNaN(diasPorSemana)) {
                    alert('Por favor, preencha todos os campos necessários.');
                    return;
                }

                // Capacidade Instalada
                var capacidadeInstalada = capacidadeNominal * 24;
                $('#capacidadeInstalada').text('A – Capacidade Instalada: ' + capacidadeInstalada + ' peças/dia');

                // Capacidade Disponível
                var capacidadeDisponivel = capacidadeNominal * horasPorSemana;
                $('#capacidadeDisponivel').text('B – Capacidade Disponível: ' + capacidadeDisponivel + ' peças/dia');

                // Capacidade Efetiva
                var horasOcorrenciasPlanejadas = 0;
                $('#tabelaOcorrencias tbody tr').each(function() {
                    var id = $(this).find('input[name="ocorrencia_id[]"]').val();
                    var horas = parseInt($(this).find('input[name="horas[]"]').val());
                    var ocorrencia = ocorrencias.find(o => o.id == id);
                    if (ocorrencia.tipo === 'PLANEJADA') {
                        horasOcorrenciasPlanejadas += horas;
                    }
                });
                var capacidadeEfetiva = (horasPorSemana - horasOcorrenciasPlanejadas) * capacidadeNominal;
                $('#capacidadeEfetiva').text('C – Capacidade Efetiva: ' + capacidadeEfetiva + ' peças/dia');

                // Capacidade Realizada
                var horasOcorrenciasTotal = 0;
                $('#tabelaOcorrencias tbody tr').each(function() {
                    var id = $(this).find('input[name="ocorrencia_id[]"]').val();
                    var horas = parseInt($(this).find('input[name="horas[]"]').val());
                    horasOcorrenciasTotal += horas;
                });
                var capacidadeRealizada = (horasPorSemana - horasOcorrenciasTotal) * capacidadeNominal;
                $('#capacidadeRealizada').text('D – Capacidade Realizada: ' + capacidadeRealizada + ' peças/dia');

                // Índices
                var grauDisponibilidade = (capacidadeDisponivel / capacidadeInstalada) * 100;
                var grauUtilizacao = (capacidadeEfetiva / capacidadeDisponivel) * 100;
                var indiceEficiencia = (capacidadeRealizada / capacidadeEfetiva) * 100;

                $('#grauDisponibilidade').text('Grau de Disponibilidade: ' + grauDisponibilidade.toFixed(2) + '%');
                $('#grauUtilizacao').text('Grau de Utilização: ' + grauUtilizacao.toFixed(2) + '%');
                $('#indiceEficiencia').text('Índice de Eficiência: ' + indiceEficiencia.toFixed(2) + '%');

                // Gravar os dados no banco de dados
                $.ajax({
                    url: 'gravar_capacidade.php',
                    method: 'POST',
                    data: {
                        maquina_id: $('#maquina_id').val(),
                        capacidade_instalada: capacidadeInstalada,
                        capacidade_disponivel: capacidadeDisponivel,
                        capacidade_efetiva: capacidadeEfetiva,
                        capacidade_realizada: capacidadeRealizada,
                        grau_disponibilidade: grauDisponibilidade.toFixed(2),
                        grau_utilizacao: grauUtilizacao.toFixed(2),
                        indice_eficiencia: indiceEficiencia.toFixed(2),
                        data: $('#data').val()
                    },
                    success: function(response) {
                        alert('Dados gravados com sucesso!');
                    },
                    error: function() {
                        alert('Erro ao gravar os dados.');
                    }
                });
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Calcular Capacidade Produtiva</h2>
        <form>
            <div class="form-group">
                <label for="usuario">Usuário:</label>
                <input type="text" class="form-control" id="usuario" value="<?php echo $_SESSION['usuario_nome']; ?>" disabled>
                <input type="hidden" name="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">
            </div>
            <div class="form-group">
                <label for="data">Data:</label>
                <input type="date" class="form-control" id="data" name="data" required>
            </div>
            <div class="form-group">
                <label for="numeroSerie">N. Série:</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="numeroSerie" name="numero_serie" readonly required>
                    <input type="hidden" id="maquina_id" name="maquina_id">
                    <input type="hidden" id="capacidade_nominal" name="capacidade_nominal">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-secondary" id="buscarMaquina">Buscar</button>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="horasPorSemana">Qtd horas/semana:</label>
                <input type="number" class="form-control" id="horasPorSemana" name="horas_por_semana" required>
            </div>
            <div class="form-group">
                <label for="diasPorSemana">Qtd dias/semana:</label>
                <input type="number" class="form-control" id="diasPorSemana" name="dias_por_semana" required>
            </div>
            <h4>Ocorrências</h4>
            <table class="table table-bordered" id="tabelaOcorrencias">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ocorrência</th>
                        <th>Horas</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <button type="button" class="btn btn-success" id="adicionarOcorrencia">+</button>
            <button type="button" class="btn btn-primary" id="calcularBtn">Calcular</button>
        </form>
        <br>
        <div id="resultados">
            <p id="capacidadeInstalada"></p>
            <p id="capacidadeDisponivel"></p>
            <p id="capacidadeEfetiva"></p>
            <p id="capacidadeRealizada"></p>
            <p id="grauDisponibilidade"></p>
            <p id="grauUtilizacao"></p>
            <p id="indiceEficiencia"></p>
        </div>
       
    </div>

    <!-- Modal para buscar máquina -->
    <div class="modal fade" id="modalMaquina" tabindex="-1" aria-labelledby="modalMaquinaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMaquinaLabel">Buscar Máquina</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="input-group mb-2">
                        <input type="text" class="form-control" id="buscarMaquinaInput" placeholder="Digite o número de série">
                        <div class="input-group-append">
                            <button type="button" class="btn btn-primary" id="buscarMaquinaBtn">Buscar</button>
                        </div>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>N. Série</th>
                                <th>Nome</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($maquinas as $maquina): ?>
                                <tr class="maquina" data-id="<?php echo $maquina['id']; ?>" data-numero_serie="<?php echo $maquina['numero_serie']; ?>" data-nome="<?php echo $maquina['nome']; ?>" data-capacidade_nominal="<?php echo $maquina['capacidade_nominal']; ?>">
                                    <td><?php echo $maquina['numero_serie']; ?></td>
                                    <td><?php echo $maquina['nome']; ?></td>
                                    <td><button type="button" class="btn btn-primary selecionarMaquina" data-id="<?php echo $maquina['id']; ?>" data-numero_serie="<?php echo $maquina['numero_serie']; ?>" data-capacidade_nominal="<?php echo $maquina['capacidade_nominal']; ?>">Escolher</button></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para buscar ocorrências -->
    <div class="modal fade" id="modalOcorrencia" tabindex="-1" aria-labelledby="modalOcorrenciaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalOcorrenciaLabel">Buscar Ocorrência</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <select class="form-control mb-2" id="tipoOcorrencia">
                        <option value="">Selecione o tipo</option>
                        <option value="PLANEJADA">PLANEJADA</option>
                        <option value="NAO_PLANEJADA">NÃO PLANEJADA</option>
                    </select>
                    <button type="button" class="btn btn-secondary mb-2" id="filtrarOcorrencias">Filtrar</button>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Descrição</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ocorrencias as $ocorrencia): ?>
                                <tr class="ocorrencia" data-id="<?php echo $ocorrencia['id']; ?>" data-descricao="<?php echo $ocorrencia['descricao']; ?>" data-tipo="<?php echo $ocorrencia['tipo']; ?>">
                                    <td><?php echo $ocorrencia['id']; ?></td>
                                    <td><?php echo $ocorrencia['descricao']; ?></td>
                                    <td><button type="button" class="btn btn-primary selecionarOcorrencia" data-id="<?php echo $ocorrencia['id']; ?>" data-descricao="<?php echo $ocorrencia['descricao']; ?>" data-linha="${contadorLinhas}">Escolher</button></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

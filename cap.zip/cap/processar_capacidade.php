<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario_id = $_POST['usuario_id'];
    $maquina_id = $_POST['maquina_id'];
    $data = $_POST['data'];
    $horas_por_semana = $_POST['horas_por_semana'];
    $dias_por_semana = $_POST['dias_por_semana'];
    $ocorrencia_ids = $_POST['ocorrencia_id'];
    $horas = $_POST['horas'];

    // Calcular capacidades
    $capacidade_instalada = $horas_por_semana * $dias_por_semana;
    $capacidade_disponivel = $capacidade_instalada; // Ajuste conforme necessidade
    $capacidade_efetiva = $capacidade_disponivel; // Ajuste conforme necessidade
    $capacidade_realizada = $capacidade_efetiva; // Ajuste conforme necessidade

    // Calcular índices
    $grau_disponibilidade = ($capacidade_disponivel / $capacidade_instalada) * 100;
    $grau_utilizacao = ($capacidade_realizada / $capacidade_disponivel) * 100;
    $indice_eficiencia = ($capacidade_realizada / $capacidade_efetiva) * 100;

    // Inserir no banco de dados
    $stmt = $pdo->prepare('INSERT INTO capacidade_produtiva (usuario_id, maquina_id, data, horas_por_semana, dias_por_semana, capacidade_instalada, capacidade_disponivel, capacidade_efetiva, capacidade_realizada, grau_disponibilidade, grau_utilizacao, indice_eficiencia) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$usuario_id, $maquina_id, $data, $horas_por_semana, $dias_por_semana, $capacidade_instalada, $capacidade_disponivel, $capacidade_efetiva, $capacidade_realizada, $grau_disponibilidade, $grau_utilizacao, $indice_eficiencia]);

    // Obter o ID do cálculo inserido
    $capacidade_produtiva_id = $pdo->lastInsertId();

    // Inserir ocorrências relacionadas
    foreach ($ocorrencia_ids as $key => $ocorrencia_id) {
        $horas_ocorrencia = $horas[$key];
        $stmt = $pdo->prepare('INSERT INTO capacidade_produtiva_ocorrencias (capacidade_produtiva_id, ocorrencia_id, horas) VALUES (?, ?, ?)');
        $stmt->execute([$capacidade_produtiva_id, $ocorrencia_id, $horas_ocorrencia]);
    }

    header('Location: relatorios_maquinas.php');
    exit;
}
?>

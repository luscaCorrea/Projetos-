<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios por Máquina - Gráficos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css">
    <style>
        body {
            font-size: 0.875rem;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }
        .sidebar .nav-link,
        .sidebar .btn {
            color: white;
        }
        .sidebar .nav-link:hover,
        .sidebar .btn:hover {
            background-color: #495057;
        }
        .sidebar .nav-link {
            display: flex;
            align-items: center;
        }
        .sidebar .nav-link .bi,
        .sidebar .nav-link .emoji {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }
        .sidebar .emoji {
            font-size: 2rem;
        }
        .sidebar .hr-divider {
            border: 0;
            border-top: 1px solid white;
            margin: 0.5rem 0;
        }
        .sidebar .btn-logoff {
            background-color: #ff9800;
            color: white;
            width: 100%;
        }
        .sidebar .btn-logoff:hover {
            background-color: #e68a00;
        }
        .submenu {
            display: none;
            list-style: none;
            padding-left: 1rem;
        }
        .nav-item:hover .submenu {
            display: block;
        }
        .sidebar .emoji-top {
            font-size: 4rem;
            text-align: center;
            width: 100%;
        }
        .btn-logoff-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
        }
        .btn-orange {
            background-color: #ff9800;
            color: white;
        }
        .btn-orange:hover {
            background-color: #e68a00;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark sidebar">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <div class="text-center emoji-top">
                    🏭
                </div>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link align-middle px-0">
                            <i class="bi bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-people"></i> <span class="ms-1 d-none d-sm-inline">Usuários</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_usuario.php" class="nav-link px-0">Cadastrar Usuários</a>
                            </li>
                            <li>
                                <a href="alterar_usuario.php" class="nav-link px-0">Alterar Usuários</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-building"></i> <span class="ms-1 d-none d-sm-inline">Setores</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_setor.php" class="nav-link px-0">Cadastrar Setores</a>
                            </li>
                            <li>
                                <a href="alterar_setor.php" class="nav-link px-0">Alterar Setores</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-gear"></i> <span class="ms-1 d-none d-sm-inline">Máquinas</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_maquina.php" class="nav-link px-0">Cadastrar Máquinas</a>
                            </li>
                            <li>
                                <a href="alterar_maquinas.php" class="nav-link px-0">Alterar Máquinas</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-exclamation-triangle"></i> <span class="ms-1 d-none d-sm-inline">Ocorrências</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_ocorrencia.php" class="nav-link px-0">Cadastrar Ocorrências</a>
                            </li>
                            <li>
                                <a href="alterar_ocorrencias.php" class="nav-link px-0">Alterar Ocorrências</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="calcular_capacidade.php" class="nav-link px-0 align-middle">
                            <i class="bi bi-graph-up"></i> <span class="ms-1 d-none d-sm-inline">Capacidade Produtiva</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-file-earmark-text"></i> <span class="ms-1 d-none d-sm-inline">Relatórios</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="relatorios_maquinas.php" class="nav-link px-0">Máquinas</a>
                            </li>
                            <li>
                                <a href="relatorios_graficos.php" class="nav-link px-0">Análises</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                </ul>
                <div class="btn-logoff-wrapper">
                    <a href="logout.php" class="btn btn-logoff">
                        <i class="bi bi-box-arrow-right"></i> Logoff
                    </a>
                </div>
            </div>
        </div>
        <div class="col py-3">
            <div class="container">
                <h2 class="mt-5"><span class="emoji">📊</span> Relatórios por Máquina - Gráficos</h2>
                <form method="get" action="relatorios_graficos.php" class="mb-3">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="data_inicial">Data Inicial:</label>
                            <input type="date" class="form-control" id="data_inicial" name="data_inicial" value="<?php echo $data_inicial; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="data_final">Data Final:</label>
                            <input type="date" class="form-control" id="data_final" name="data_final" value="<?php echo $data_final; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="numero_serie">N. Série:</label>
                            <input type="text" class="form-control" id="numero_serie" name="numero_serie" value="<?php echo $numero_serie; ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-orange"><i class="bi bi-funnel"></i> Filtrar</button>
                </form>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <canvas id="grauDisponibilidadeChart"></canvas>
                    </div>
                    <div class="col-md-4 mb-3">
                        <canvas id="grauUtilizacaoChart"></canvas>
                    </div>
                    <div class="col-md-4 mb-3">
                        <canvas id="indiceEficienciaChart"></canvas>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <canvas id="capacidadeInstaladaChart"></canvas>
                    </div>
                    <div class="col-md-6 mb-3">
                        <canvas id="capacidadeDisponivelChart"></canvas>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <canvas id="capacidadeEfetivaChart"></canvas>
                    </div>
                    <div class="col-md-6 mb-3">
                        <canvas id="capacidadeRealizadaChart"></canvas>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const relatorios = <?php echo json_encode($relatorios); ?>;

                        const labels = relatorios.map(relatorio => relatorio.data_calculo);
                        const grauDisponibilidadeData = relatorios.map(relatorio => relatorio.g_disponibilidade);
                        const grauUtilizacaoData = relatorios.map(relatorio => relatorio.g_utilizacao);
                        const indiceEficienciaData = relatorios.map(relatorio => relatorio.i_eficiencia);
                        const capacidadeInstaladaData = relatorios.map(relatorio => relatorio.capacidade_instalada);
                        const capacidadeDisponivelData = relatorios.map(relatorio => relatorio.capacidade_disponivel);
                        const capacidadeEfetivaData = relatorios.map(relatorio => relatorio.capacidade_efetiva);
                        const capacidadeRealizadaData = relatorios.map(relatorio => relatorio.capacidade_realizada);

                        const ctx1 = document.getElementById('grauDisponibilidadeChart').getContext('2d');
                        new Chart(ctx1, {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Grau de Disponibilidade (%)',
                                    data: grauDisponibilidadeData,
                                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });

                        const ctx2 = document.getElementById('grauUtilizacaoChart').getContext('2d');
                        new Chart(ctx2, {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Grau de Utilização (%)',
                                    data: grauUtilizacaoData,
                                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                                    borderColor: 'rgba(153, 102, 255, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });

                        const ctx3 = document.getElementById('indiceEficienciaChart').getContext('2d');
                        new Chart(ctx3, {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Índice de Eficiência (%)',
                                    data: indiceEficienciaData,
                                    backgroundColor: 'rgba(255, 159, 64, 0.2)',
                                    borderColor: 'rgba(255, 159, 64, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });

                        const ctx4 = document.getElementById('capacidadeInstaladaChart').getContext('2d');
                        new Chart(ctx4, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Capacidade Instalada',
                                    data: capacidadeInstaladaData,
                                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                    borderColor: 'rgba(255, 99, 132, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });

                        const ctx5 = document.getElementById('capacidadeDisponivelChart').getContext('2d');
                        new Chart(ctx5, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Capacidade Disponível',
                                    data: capacidadeDisponivelData,
backgroundColor: 'rgba(54, 162, 235, 0.2)',
borderColor: 'rgba(54, 162, 235, 1)',
borderWidth: 1
}]
},
options: {
scales: {
y: {
beginAtZero: true
}
}
}
});

const ctx6 = document.getElementById('capacidadeEfetivaChart').getContext('2d');
new Chart(ctx6, {
type: 'line',
data: {
labels: labels,
datasets: [{
label: 'Capacidade Efetiva',
data: capacidadeEfetivaData,
backgroundColor: 'rgba(75, 192, 192, 0.2)',
borderColor: 'rgba(75, 192, 192, 1)',
borderWidth: 1
}]
},
options: {
scales: {
y: {
beginAtZero: true
}
}
}
});

const ctx7 = document.getElementById('capacidadeRealizadaChart').getContext('2d');
new Chart(ctx7, {
type: 'line',
data: {
labels: labels,
datasets: [{
label: 'Capacidade Realizada',
data: capacidadeRealizadaData,
backgroundColor: 'rgba(153, 102, 255, 0.2)',
borderColor: 'rgba(153, 102, 255, 1)',
borderWidth: 1
}]
},
options: {
scales: {
y: {
beginAtZero: true
}
}
}
});
});
</script>
<a href="menu.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Voltar</a>
</div>
</div>
</div>
</div>
</body>
</html>


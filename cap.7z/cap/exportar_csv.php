<?php
include('sessao.php');
include('conexao.php');

$data = isset($_GET['data']) ? $_GET['data'] : '';
$numero_serie = isset($_GET['numero_serie']) ? $_GET['numero_serie'] : '';

$query = 'SELECT cp.id, m.numero_serie, cp.capacidade_instalada, cp.capacidade_disponivel, cp.capacidade_efetiva, cp.capacidade_realizada, cp.data_calculo FROM capacidade_produtiva cp JOIN maquinas m ON cp.maquina_id = m.id WHERE 1=1';
$params = [];

if ($data) {
    $query .= ' AND cp.data_calculo = ?';
    $params[] = $data;
}

if ($numero_serie) {
    $query .= ' AND m.numero_serie = ?';
    $params[] = $numero_serie;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="relatorios.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'N. Série', 'C. Inst', 'C. Disp', 'C. Ef', 'C. Real', 'Data Cálculo']);

foreach ($relatorios as $relatorio) {
    fputcsv($output, $relatorio);
}

fclose($output);
exit;
?>

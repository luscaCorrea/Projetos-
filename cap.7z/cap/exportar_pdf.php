<?php
require('fpdf.php');
include('sessao.php');
include('conexao.php');

$data = isset($_GET['data']) ? $_GET['data'] : '';
$numero_serie = isset($_GET['numero_serie']) ? $_GET['numero_serie'] : '';

$query = 'SELECT cp.id, m.numero_serie, cp.capacidade_instalada, cp.capacidade_disponivel, cp.capacidade_efetiva, cp.capacidade_realizada, cp.data_calculo FROM capacidade_produtiva cp JOIN maquinas m ON cp.maquina_id = m.id WHERE 1=1';
$params = [];

if ($data) {
    $query .= ' AND cp.data_calculo = ?';
    $params[] = $data;
}

if ($numero_serie) {
    $query .= ' AND m.numero_serie = ?';
    $params[] = $numero_serie;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Relatorios por Maquina', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(10, 10, 'ID', 1);
$pdf->Cell(30, 10, 'N. Serie', 1);
$pdf->Cell(20, 10, 'C. Inst', 1);
$pdf->Cell(20, 10, 'C. Disp', 1);
$pdf->Cell(20, 10, 'C. Ef', 1);
$pdf->Cell(20, 10, 'C. Real', 1);
$pdf->Cell(20, 10, 'Data Cálculo', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 12);
foreach ($relatorios as $relatorio) {
    $pdf->Cell(10, 10, $relatorio['id'], 1);
    $pdf->Cell(30, 10, $relatorio['numero_serie'], 1);
    $pdf->Cell(20, 10, $relatorio['capacidade_instalada'], 1);
    $pdf->Cell(20, 10, $relatorio['capacidade_disponivel'], 1);
    $pdf->Cell(20, 10, $relatorio['capacidade_efetiva'], 1);
    $pdf->Cell(20, 10, $relatorio['capacidade_realizada'], 1);
    $pdf->Cell(20, 10, $relatorio['data_calculo'], 1);
    $pdf->Ln();
}

$pdf->Output('D', 'relatorios.pdf');
exit;
?>

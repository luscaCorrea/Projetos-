<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $maquina_id = $_POST['maquina_id'];
    $capacidade_instalada = $_POST['capacidade_instalada'];
    $capacidade_disponivel = $_POST['capacidade_disponivel'];
    $capacidade_efetiva = $_POST['capacidade_efetiva'];
    $capacidade_realizada = $_POST['capacidade_realizada'];
    $grau_disponibilidade = $_POST['grau_disponibilidade'];
    $grau_utilizacao = $_POST['grau_utilizacao'];
    $indice_eficiencia = $_POST['indice_eficiencia'];
    $data = $_POST['data'];

    $stmt = $pdo->prepare('INSERT INTO capacidade_produtiva (maquina_id, capacidade_instalada, capacidade_disponivel, capacidade_efetiva, capacidade_realizada, g_disponibilidade, g_utilizacao, i_eficiencia, data_calculo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$maquina_id, $capacidade_instalada, $capacidade_disponivel, $capacidade_efetiva, $capacidade_realizada, $grau_disponibilidade, $grau_utilizacao, $indice_eficiencia, $data]);

    echo 'Success';
} else {
    echo 'Invalid request';
}
?>

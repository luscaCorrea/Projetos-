<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $numero_serie = $_POST['numero_serie'];
    $capacidade_nominal = $_POST['capacidade_nominal'];

    $stmt = $pdo->prepare('UPDATE maquinas SET nome = ?, numero_serie = ?, capacidade_nominal = ? WHERE id = ?');
    $stmt->execute([$nome, $numero_serie, $capacidade_nominal, $id]);

    header('Location: alterar_maquinas.php');
    exit;
}
?>

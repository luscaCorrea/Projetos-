<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios por Máquina</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css">
    <style>
        body {
            font-size: 0.875rem;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }
        .sidebar .nav-link,
        .sidebar .btn {
            color: white;
        }
        .sidebar .nav-link:hover,
        .sidebar .btn:hover {
            background-color: #495057;
        }
        .sidebar .nav-link {
            display: flex;
            align-items: center;
        }
        .sidebar .nav-link .bi,
        .sidebar .nav-link .emoji {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }
        .sidebar .emoji {
            font-size: 2rem;
        }
        .sidebar .hr-divider {
            border: 0;
            border-top: 1px solid white;
            margin: 0.5rem 0;
        }
        .sidebar .btn-logoff {
            background-color: #ff9800;
            color: white;
            width: 100%;
        }
        .sidebar .btn-logoff:hover {
            background-color: #e68a00;
        }
        .submenu {
            display: none;
            list-style: none;
            padding-left: 1rem;
        }
        .nav-item:hover .submenu {
            display: block;
        }
        .sidebar .emoji-top {
            font-size: 4rem;
            text-align: center;
            width: 100%;
        }
        .btn-logoff-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    <script>
        window.jsPDF = window.jspdf.jsPDF;

        function exportarPDF() {
            const doc = new jsPDF();
            doc.text("Relatórios por Máquina", 10, 10);

            const head = [['ID', 'N. Série', 'C. Inst', 'C. Disp', 'C. Ef', 'C. Real', 'Grau de Disponibilidade', 'Grau de Utilização', 'Índice de Eficiência', 'Data Cálculo']];
            const body = [];

            const rows = document.querySelectorAll("table tbody tr");
            rows.forEach((row, index) => {
                const cells = row.querySelectorAll("td");
                const rowData = [];
                cells.forEach(cell => {
                    rowData.push(cell.innerText);
                });
                body.push(rowData);
            });

            doc.autoTable({
                head: head,
                body: body,
                startY: 20,
                styles: { fillColor: [255, 255, 255], textColor: [0, 0, 0] },
                alternateRowStyles: { fillColor: [240, 240, 240] },
                headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255] },
                theme: 'grid',
                margin: { top: 20 },
            });

            doc.save("relatorios_maquinas.pdf");
        }
    </script>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark sidebar">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <div class="text-center emoji-top">
                    🏭
                </div>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link align-middle px-0">
                            <i class="bi bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-people"></i> <span class="ms-1 d-none d-sm-inline">Usuários</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_usuario.php" class="nav-link px-0">Cadastrar Usuários</a>
                            </li>
                            <li>
                                <a href="alterar_usuario.php" class="nav-link px-0">Alterar Usuários</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-building"></i> <span class="ms-1 d-none d-sm-inline">Setores</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_setor.php" class="nav-link px-0">Cadastrar Setores</a>
                            </li>
                            <li>
                                <a href="alterar_setor.php" class="nav-link px-0">Alterar Setores</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-gear"></i> <span class="ms-1 d-none d-sm-inline">Máquinas</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_maquina.php" class="nav-link px-0">Cadastrar Máquinas</a>
                            </li>
                            <li>
                                <a href="alterar_maquinas.php" class="nav-link px-0">Alterar Máquinas</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-exclamation-triangle"></i> <span class="ms-1 d-none d-sm-inline">Ocorrências</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_ocorrencia.php" class="nav-link px-0">Cadastrar Ocorrências</a>
                            </li>
                            <li>
                                <a href="alterar_ocorrencias.php" class="nav-link px-0">Alterar Ocorrências</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="calcular_capacidade.php" class="nav-link px-0 align-middle">
                            <i class="bi bi-graph-up"></i> <span class="ms-1 d-none d-sm-inline">Capacidade Produtiva</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-file-earmark-text"></i> <span class="ms-1 d-none d-sm-inline">Relatórios</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="relatorios_maquinas.php" class="nav-link px-0">Máquinas</a>
                            </li>
                            <li>
                                <a href="relatorios_graficos.php" class="nav-link px-0">Análises</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                </ul>
                <div class="btn-logoff-wrapper">
                    <a href="logout.php" class="btn btn-logoff">
                        <i class="bi bi-box-arrow-right"></i> Logoff
                    </a>
                </div>
            </div>
        </div>
        <div class="col py-3">
            <div class="container">
                <h2 class="mt-5"><span class="emoji">📊</span> Relatórios por Máquina</h2>
                <form method="get" action="relatorios_maquinas.php" class="mb-3">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="data_inicial">Data Inicial:</label>
                            <input type="date" class="form-control" id="data_inicial" name="data_inicial" value="<?php echo $data_inicial; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="data_final">Data Final:</label>
                            <input type="date" class="form-control" id="data_final" name="data_final" value="<?php echo $data_final; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="numero_serie">N. Série:</label>
                            <input type="text" class="form-control" id="numero_serie" name="numero_serie" value="<?php echo $numero_serie; ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-orange"><i class="bi bi-funnel"></i> Filtrar</button>
                </form>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>N. Série</th>
                            <th>C. Inst</th>
                            <th>C. Disp</th>
                            <th>C. Ef</th>
                            <th>C. Real</th>
                            <th>Grau de Disponibilidade</th>
                            <th>Grau de Utilização</th>
                            <th>Índice de Eficiência</th>
                            <th>Data Cálculo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($relatorios as $relatorio): ?>
                            <tr>
                                <td><?php echo $relatorio['id']; ?></td>
                                <td><?php echo $relatorio['numero_serie']; ?></td>
                                <td><?php echo $relatorio['capacidade_instalada']; ?></td>
                                <td><?php echo $relatorio['capacidade_disponivel']; ?></td>
                                <td><?php echo $relatorio['capacidade_efetiva']; ?></td>
                                <td><?php echo $relatorio['capacidade_realizada']; ?></td>
                                <td><?php echo $relatorio['g_disponibilidade']; ?></td>
                                <td><?php echo $relatorio['g_utilizacao']; ?></td>
                                <td><?php echo $relatorio['i_eficiencia']; ?></td>
                                <td><?php echo $relatorio['data_calculo']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="exportar_csv.php?data_inicial=<?php echo $data_inicial; ?>&data_final=<?php echo $data_final; ?>&numero_serie=<?php echo $numero_serie; ?>" class="btn btn-orange"><i class="bi bi-file-earmark-spreadsheet"></i> Exportar CSV</a>
                <button onclick="exportarPDF()" class="btn btn-danger"><i class="bi bi-file-earmark-pdf"></i> Exportar PDF</button>
                <a href="menu.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Voltar</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = md5($_POST['senha']);
    $tipo = $_POST['tipo'];
    $status = $_POST['status'];
    $observacoes = $_POST['observacoes'];

    $stmt = $pdo->prepare('INSERT INTO usuarios (nome, email, senha, tipo, status, observacoes) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$nome, $email, $senha, $tipo, $status, $observacoes]);

    header('Location: menu.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Usuário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css">
    <style>
        body {
            font-size: 0.875rem;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }
        .sidebar .nav-link,
        .sidebar .btn {
            color: white;
        }
        .sidebar .nav-link:hover,
        .sidebar .btn:hover {
            background-color: #495057;
        }
        .sidebar .nav-link {
            display: flex;
            align-items: center;
        }
        .sidebar .nav-link .bi,
        .sidebar .nav-link .emoji {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }
        .sidebar .emoji {
            font-size: 2rem;
        }
        .sidebar .hr-divider {
            border: 0;
            border-top: 1px solid white;
            margin: 0.5rem 0;
        }
        .sidebar .btn-logoff {
            background-color: #ff9800;
            color: white;
            width: 100%;
        }
        .sidebar .btn-logoff:hover {
            background-color: #e68a00;
        }
        .submenu {
            display: none;
            list-style: none;
            padding-left: 1rem;
        }
        .nav-item:hover .submenu {
            display: block;
        }
        .sidebar .emoji-top {
            font-size: 4rem;
            text-align: center;
            width: 100%;
        }
        .btn-logoff-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
        }
        .btn-orange {
            background-color: #ff9800;
            color: white;
        }
        .btn-orange:hover {
            background-color: #e68a00;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark sidebar">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <div class="text-center emoji-top">
                    🏭
                </div>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="menu.php" class="nav-link align-middle px-0">
                            <i class="bi bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-people"></i> <span class="ms-1 d-none d-sm-inline">Usuários</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_usuario.php" class="nav-link px-0">Cadastrar Usuários</a>
                            </li>
                            <li>
                                <a href="alterar_usuario.php" class="nav-link px-0">Alterar Usuários</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-building"></i> <span class="ms-1 d-none d-sm-inline">Setores</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_setor.php" class="nav-link px-0">Cadastrar Setores</a>
                            </li>
                            <li>
                                <a href="alterar_setor.php" class="nav-link px-0">Alterar Setores</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-gear"></i> <span class="ms-1 d-none d-sm-inline">Máquinas</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_maquina.php" class="nav-link px-0">Cadastrar Máquinas</a>
                            </li>
                            <li>
                                <a href="alterar_maquinas.php" class="nav-link px-0">Alterar Máquinas</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-exclamation-triangle"></i> <span class="ms-1 d-none d-sm-inline">Ocorrências</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_ocorrencia.php" class="nav-link px-0">Cadastrar Ocorrências</a>
                            </li>
                            <li>
                                <a href="alterar_ocorrencias.php" class="nav-link px-0">Alterar Ocorrências</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="calcular_capacidade.php" class="nav-link px-0 align-middle">
                            <i class="bi bi-graph-up"></i> <span class="ms-1 d-none d-sm-inline">Capacidade Produtiva</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-file-earmark-text"></i> <span class="ms-1 d-none d-sm-inline">Relatórios</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="relatorios_maquinas.php" class="nav-link px-0">Máquinas</a>
                            </li>
                            <li>
                                <a href="relatorios_graficos.php" class="nav-link px-0">Análises</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                </ul>
                <div class="btn-logoff-wrapper">
                    <a href="logout.php" class="btn btn-logoff">
                        <i class="bi bi-box-arrow-right"></i> Logoff
                    </a>
                </div>
            </div>
        </div>
        <div class="col py-3">
            <div class="container">
                <h2 class="mt-5"><i class="bi bi-person-plus"></i> Cadastrar Usuários</h2>
                <form method="post" action="cadastrar_usuario.php">
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha:</label>
                        <input type="password" class="form-control" id="senha" name="senha" required>
                    </div>
                    <div class="form-group">
                        <label for="tipo">Tipo:</label>
                        <select class="form-control" id="tipo" name="tipo" required>
                            <option value="ADMIN">ADMIN</option>
                            <option value="USER">USER</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status">Status:</label>
                        <select class="form-control" id="status" name="status" required>
                            <option value="ATIVO">ATIVO</option>
                            <option value="INATIVO">INATIVO</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="observacoes">Observações:</label>
                        <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
                    </div>
                    <button type="submit" class="btn btn-orange">
                        <i class="bi bi-check-lg"></i> Cadastrar
                    </button>
                    <a href="menu.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Voltar
                    </a>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $descricao = $_POST['descricao'];
    $tipo = $_POST['tipo'];

    $stmt = $pdo->prepare('UPDATE ocorrencias SET descricao = ?, tipo = ? WHERE id = ?');
    $stmt->execute([$descricao, $tipo, $id]);

    header('Location: alterar_ocorrencias.php');
    exit;
}
?>

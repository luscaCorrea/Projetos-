<?php
include('sessao.php');
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['editar'])) {
        $id = $_POST['id'];
        $descricao = $_POST['descricao'];
        $setor_id = $_POST['setor_id'];
        $numero_serie = $_POST['numero_serie'];
        $capacidade_nominal = $_POST['capacidade_nominal'];
        $observacoes = $_POST['observacoes'];

        $stmt = $pdo->prepare('UPDATE maquinas SET nome = ?, setor_id = ?, numero_serie = ?, capacidade_nominal = ?, observacoes = ? WHERE id = ?');
        $stmt->execute([$descricao, $setor_id, $numero_serie, $capacidade_nominal, $observacoes, $id]);

        header('Location: alterar_maquinas.php');
        exit;
    } elseif (isset($_POST['apagar'])) {
        $id = $_POST['id'];

        $stmt = $pdo->prepare('DELETE FROM maquinas WHERE id = ?');
        $stmt->execute([$id]);

        header('Location: alterar_maquinas.php');
        exit;
    }
}

// Obter a lista de setores para o dropdown
$stmt = $pdo->query('SELECT id, nome FROM setores');
$setores = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter a lista de máquinas
$stmt = $pdo->query('SELECT m.id, m.nome, m.numero_serie, m.capacidade_nominal, m.observacoes, s.id AS setor_id, s.nome AS setor_nome FROM maquinas m JOIN setores s ON m.setor_id = s.id');
$maquinas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Máquinas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css">
    <style>
        body {
            font-size: 0.875rem;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }
        .sidebar .nav-link,
        .sidebar .btn {
            color: white;
        }
        .sidebar .nav-link:hover,
        .sidebar .btn:hover {
            background-color: #495057;
        }
        .sidebar .nav-link {
            display: flex;
            align-items: center;
        }
        .sidebar .nav-link .bi,
        .sidebar .nav-link .emoji {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }
        .sidebar .emoji {
            font-size: 2rem;
        }
        .sidebar .hr-divider {
            border: 0;
            border-top: 1px solid white;
            margin: 0.5rem 0;
        }
        .sidebar .btn-logoff {
            background-color: #ff9800;
            color: white;
            width: 100%;
        }
        .sidebar .btn-logoff:hover {
            background-color: #e68a00;
        }
        .submenu {
            display: none;
            list-style: none;
            padding-left: 1rem;
        }
        .nav-item:hover .submenu {
            display: block;
        }
        .sidebar .emoji-top {
            font-size: 4rem;
            text-align: center;
            width: 100%;
        }
        .btn-logoff-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
        }
        .btn-orange {
            background-color: #ff9800;
            color: white;
        }
        .btn-orange:hover {
            background-color: #e68a00;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark sidebar">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <div class="text-center emoji-top">
                    🏭
                </div>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link align-middle px-0">
                            <i class="bi bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-people"></i> <span class="ms-1 d-none d-sm-inline">Usuários</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_usuario.php" class="nav-link px-0">Cadastrar Usuários</a>
                            </li>
                            <li>
                                <a href="alterar_usuario.php" class="nav-link px-0">Alterar Usuários</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-building"></i> <span class="ms-1 d-none d-sm-inline">Setores</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_setor.php" class="nav-link px-0">Cadastrar Setores</a>
                            </li>
                            <li>
                                <a href="alterar_setor.php" class="nav-link px-0">Alterar Setores</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-gear"></i> <span class="ms-1 d-none d-sm-inline">Máquinas</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_maquina.php" class="nav-link px-0">Cadastrar Máquinas</a>
                            </li>
                            <li>
                                <a href="alterar_maquinas.php" class="nav-link px-0">Alterar Máquinas</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-exclamation-triangle"></i> <span class="ms-1 d-none d-sm-inline">Ocorrências</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="cadastrar_ocorrencia.php" class="nav-link px-0">Cadastrar Ocorrências</a>
                            </li>
                            <li>
                                <a href="alterar_ocorrencias.php" class="nav-link px-0">Alterar Ocorrências</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="calcular_capacidade.php" class="nav-link px-0 align-middle">
                            <i class="bi bi-graph-up"></i> <span class="ms-1 d-none d-sm-inline">Capacidade Produtiva</span>
                        </a>
                    </li>
                    <hr class="hr-divider">
                    <li class="nav-item">
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="bi bi-file-earmark-text"></i> <span class="ms-1 d-none d-sm-inline">Relatórios</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="relatorios_maquinas.php" class="nav-link px-0">Máquinas</a>
                            </li>
                            <li>
                                <a href="relatorios_graficos.php" class="nav-link px-0">Análises</a>
                            </li>
                        </ul>
                    </li>
                    <hr class="hr-divider">
                </ul>
                <div class="btn-logoff-wrapper">
                    <a href="logout.php" class="btn btn-logoff">
                        <i class="bi bi-box-arrow-right"></i> Logoff
                    </a>
                </div>
            </div>
        </div>
        <div class="col py-3">
            <div class="container">
                <h2 class="mt-5"><span class="emoji">🔧</span> Alterar Máquinas</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Descrição</th>
                            <th>Setor</th>
                            <th>N. Série</th>
                            <th>V. Nominal (peças/horas)</th>
                            <th>Observações</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($maquinas as $maquina): ?>
                            <tr>
                                <td><?php echo $maquina['id']; ?></td>
                                <td><?php echo $maquina['nome']; ?></td>
                                <td><?php echo $maquina['setor_nome']; ?></td>
                                <td><?php echo $maquina['numero_serie']; ?></td>
                                <td><?php echo $maquina['capacidade_nominal']; ?></td>
                                <td><?php echo $maquina['observacoes']; ?></td>
                                <td>
                                    <button class="btn btn-orange editarMaquina" 
                                            data-id="<?php echo $maquina['id']; ?>" 
                                            data-descricao="<?php echo $maquina['nome']; ?>" 
                                            data-setor_id="<?php echo $maquina['setor_id']; ?>" 
                                            data-numero_serie="<?php echo $maquina['numero_serie']; ?>" 
                                            data-capacidade_nominal="<?php echo $maquina['capacidade_nominal']; ?>" 
                                            data-observacoes="<?php echo $maquina['observacoes']; ?>"
                                            data-toggle="modal" 
                                            data-target="#modalEditarMaquina">
                                        <i class="bi bi-pencil"></i> Editar
                                    </button>
                                    <button class="btn btn-danger apagarMaquina" 
                                            data-id="<?php echo $maquina['id']; ?>"
                                            data-toggle="modal" 
                                            data-target="#modalApagarMaquina">
                                        <i class="bi bi-trash"></i> Apagar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="menu.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Voltar</a>
            </div>

            <!-- Modal para editar máquina -->
            <div class="modal fade" id="modalEditarMaquina" tabindex="-1" aria-labelledby="modalEditarMaquinaLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalEditarMaquinaLabel">Editar Máquina</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="post" action="alterar_maquinas.php">
                                <input type="hidden" name="id" id="maquinaId">
                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" required>
                                </div>
                                <div class="form-group">
                                    <label for="setor_id">Setor:</label>
                                    <select class="form-control" id="setor_id" name="setor_id" required>
                                        <?php foreach ($setores as $setor): ?>
                                            <option value="<?php echo $setor['id']; ?>"><?php echo $setor['nome']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="numero_serie">N. Série:</label>
                                    <input type="text" class="form-control" id="numero_serie" name="numero_serie" required>
                                </div>
                                <div class="form-group">
                                    <label for="capacidade_nominal">V. Nominal (peças/horas):</label>
                                    <input type="number" class="form-control" id="capacidade_nominal" name="capacidade_nominal" required>
                                </div>
                                <div class="form-group">
                                    <label for="observacoes">Observações:</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
                                </div>
                                <button type="submit" class="btn btn-orange" name="editar"><i class="bi bi-check-circle"></i> Salvar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal para apagar máquina -->
            <div class="modal fade" id="modalApagarMaquina" tabindex="-1" aria-labelledby="modalApagarMaquinaLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalApagarMaquinaLabel">Apagar Máquina</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Tem certeza que deseja apagar esta máquina?</p>
                            <form method="post" action="alterar_maquinas.php">
                                <input type="hidden" name="id" id="maquinaIdApagar">
                                <button type="submit" class="btn btn-danger" name="apagar"><i class="bi bi-trash"></i> Apagar</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="bi bi-x-circle"></i> Cancelar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('.editarMaquina').click(function(){
            var id = $(this).data('id');
            var descricao = $(this).data('descricao');
            var setor_id = $(this).data('setor_id');
            var numero_serie = $(this).data('numero_serie');
            var capacidade_nominal = $(this).data('capacidade_nominal');
            var observacoes = $(this).data('observacoes');

            $('#maquinaId').val(id);
            $('#descricao').val(descricao);
            $('#setor_id').val(setor_id);
            $('#numero_serie').val(numero_serie);
            $('#capacidade_nominal').val(capacidade_nominal);
            $('#observacoes').val(observacoes);

            $('#modalEditarMaquina').modal('show');
        });

        $('.apagarMaquina').click(function(){
            var id = $(this).data('id');

            $('#maquinaIdApagar').val(id);

            $('#modalApagarMaquina').modal('show');
        });
    });
</script>
</body>
</html>

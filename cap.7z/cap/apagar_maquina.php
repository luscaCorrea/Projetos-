<?php
include('sessao.php');
include('conexao.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare('DELETE FROM maquinas WHERE id = ?');
    $stmt->execute([$id]);

    header('Location: alterar_maquinas.php');
    exit;
}
?>
